APTREX FARM - ANDROID OVERLAY PROJECT
=====================================

HOW TO BUILD APK ON GITHUB (NO PC REQUIRED):
1. Extract this ZIP file.
2. Create a new repository on GitHub (e.g. aptrex-farm-overlay).
3. Upload all files (including the .github/workflows/build-apk.yml file) to your GitHub repo.
   Note: If your phone file manager hides the .github folder, on GitHub click:
   "Add file" -> "Create new file" -> name it .github/workflows/build-apk.yml -> paste the workflow YAML.
4. Go to the "Actions" tab in your GitHub repo.
5. Open "Build Android APK" and wait ~2 minutes for the green checkmark.
6. Scroll down to "Artifacts", download "aptrex-farm-apk", unzip it, and install app-debug.apk on your phone!
7. Open the app -> tap "START FLOATING OVERLAY" -> allow "Display over other apps".

OR BUILD LOCALLY IN ANDROID STUDIO:
1. Open the extracted folder in Android Studio.
2. Click Build > Build Bundle(s) / APK(s) > Build APK(s).

Your floating Goku icon and golden SSJ4 background artwork are already included in:
  app/src/main/res/drawable/ic_floating_icon.png
  app/src/main/res/drawable/bg_menu_artwork.jpg
